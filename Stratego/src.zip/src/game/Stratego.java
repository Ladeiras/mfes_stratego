/*
 */
package game;

/**
 *
 * @author Paulo Faria Reis <paulo@fariareis.com>
 */
public class Stratego {

   /**
    * Ponto de entrada da aplicação. Cria uma instância da classe que formaliza
    * o modelo aplicacional MVC.
    *
    * @param args
    */
   public static void main(String args[]) {
	StrategoGame strategoGame = new StrategoGame();
   }
}
